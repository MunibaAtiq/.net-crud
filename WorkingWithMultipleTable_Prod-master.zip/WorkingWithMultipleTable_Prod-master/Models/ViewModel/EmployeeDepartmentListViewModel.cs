﻿namespace WorkingWithMultipleTable_Prod.Models.ViewModel
{
    public class EmployeeDepartmentListViewModel
    {
        public List<Employee> employees { get; set; }
        public List<Department> departments { get; set; }
    }
}
